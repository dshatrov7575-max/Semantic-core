"""Test world for core-ontology/0.3 + negative/positive vectors.

The world uses symbolic references ("@S:name" source, "@C:name" claim, {"$ev": [source, quote]} evidence).
finalize() computes every content address (source_id, claim_id, receipt_id), byte spans and Ed25519
signatures, so a mutated world stays consistent except for the one rule a vector targets.
Trust anchors (W["__trust__"]) and the content store are returned SEPARATELY from the dataset.
All persons, organisations and numbers are fictional.

python3 fixtures.py  -> data/world_valid.json, data/trust_anchors.json, data/vectors_manifest.json
"""
import base64
import copy
import hashlib
import json
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from jcs import digest, canon_bytes
from validator import inn_ok, ogrn_ok, ogrnip_ok, text_digest_of, publication_address
from dataset import DatasetVersion

HERE = Path(__file__).resolve().parent
SV = "core-ontology/0.2"       # records of the nine kinds known since 0.2: their producers and content addresses do not change
SV3 = "core-ontology/0.3"      # records that use the vocabulary of 0.3 (schema definitions, THING, schema.is_a, tenant predicates)
SV4 = "core-ontology/0.4"      # records that use the vocabulary of 0.4 (a dataset version as a source, evidence by a row)
T = "tnt_demo"


def _ctl(v, coef):
    return str(sum(c * int(x) for c, x in zip(coef, v)) % 11 % 10)


def inn10(p9):
    return p9 + _ctl(p9, [2, 4, 10, 3, 5, 9, 4, 6, 8])


def inn12(p10):
    a = p10 + _ctl(p10, [7, 2, 4, 10, 3, 5, 9, 4, 6, 8])
    return a + _ctl(a, [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8])


def ogrn(p12):
    return p12 + str(int(p12) % 11 % 10)


def ogrnip(p14):
    return p14 + str(int(p14) % 13 % 10)


INN_DEV, OGRN_DEV = inn10("501200731"), ogrn("121500000731")
OGRN_TRUB, INN_TRUB = ogrn("110290001744"), inn10("290100174")
INN_LOMOV = inn12("6952031418")
INN_IP, OGRNIP_IP = inn12("5012887766"), ogrnip("32650120000412")
INN_NAMESAKE = inn12("7707123450")
assert all(map(inn_ok, (INN_DEV, INN_TRUB, INN_LOMOV, INN_IP, INN_NAMESAKE)))
assert ogrn_ok(OGRN_DEV) and ogrn_ok(OGRN_TRUB) and ogrnip_ok(OGRNIP_IP)

SEEDS = {"key_ts_1": hashlib.sha256(b"demo-seed:key_ts_1").digest(),
         "OTHER": hashlib.sha256(b"demo-seed:not-registered").digest()}


def b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def pub(seed):
    return b64u(Ed25519PrivateKey.from_private_bytes(seed).public_key().public_bytes_raw())


def mk(level, *cats):
    return {"level": level, "categories": list(cats)}


PUB, INT = mk("PUBLIC"), mk("INTERNAL")
PUB_PD = mk("PUBLIC", "PERSONAL_DATA")
CONF_PD = mk("CONFIDENTIAL", "PERSONAL_DATA")
CONF_CS = mk("CONFIDENTIAL", "COMMERCIAL_SECRET")
CONF_CS_PD = mk("CONFIDENTIAL", "PERSONAL_DATA", "COMMERCIAL_SECRET")


def srch(scope, query, at, src=None):
    s = {"search_scope": scope, "query": query, "performed_at": at, "performed_by": "usr_bank_officer"}
    if src:
        s["result_source_id"] = "@S:" + src
    return s


REGISTRY_COLUMNS = [
    {"name": "ogrn", "type": "STRING", "marking": PUB, "identifier_scheme": "ru.ogrn"},
    {"name": "inn", "type": "STRING", "marking": PUB, "identifier_scheme": "ru.inn"},
    {"name": "name", "type": "STRING", "marking": PUB},
    {"name": "address", "type": "STRING", "marking": PUB, "predicate": "entity.registered_address"},
    {"name": "director", "type": "STRING", "marking": CONF_PD},
    {"name": "registered_on", "type": "DATE", "marking": PUB},
    {"name": "active", "type": "BOOLEAN", "marking": PUB},
    {"name": "employees", "type": "INTEGER", "marking": INT}]
REGISTRY_ROWS = [
    {"ogrn": OGRN_DEV, "inn": INN_DEV, "name": "ООО «Заречье-Девелопмент»", "address": "Московская обл., г. Заречный, ул. Заречная, д. 1",
     "director": "Ломов Аркадий Семёнович", "registered_on": "2021-02-12", "active": True, "employees": 48},
    {"ogrn": OGRN_TRUB, "inn": INN_TRUB, "name": "АО «Трубопроводстрой»", "address": "г. Архангельск, пр. Ломоносова, д. 7",
     "director": "Седов Пётр Ильич", "registered_on": "2002-06-03", "active": True, "employees": 1200},
    {"ogrn": ogrn("102770000001"), "inn": inn10("770700001"), "name": "ООО «Альфа-Сервис»", "address": "г. Москва, ул. Лесная, д. 3",
     "director": "Крылова Анна Олеговна", "registered_on": "2002-11-18", "active": False, "employees": None},
    {"ogrn": ogrn("115500000002"), "inn": inn10("500100002"), "name": "ООО «Бета»", "address": "Московская обл., г. Заречный, ул. Мира, д. 9",
     "director": "Нечаев Олег Игоревич", "registered_on": "2015-04-01", "active": True, "employees": 3},
    {"ogrn": ogrn("120500000003"), "inn": inn10("500100003"), "name": "ООО «Гамма»", "address": None,
     "director": None, "registered_on": "2020-08-20", "active": True, "employees": 0}]


# the key of the demonstration dataset. In production it is 32 random bytes kept by the loader; here it is a constant
# of the test world (so that the world is reproducible) — whoever has this file can open the hidden cells of the DEMO rows
DEMO_DATASET_KEY = hashlib.sha256(b"ac demo dataset key (test world only, never for real data)").digest()


def demo_registry(rows=None, columns=None, key=("ogrn",), chunk_rows=4, subject=("ogrn", "inn"), **kw):
    """the demonstration dataset version; the row secrets are derived from DEMO_DATASET_KEY and the key of the row"""
    return DatasetVersion("dst_registry_demo", T, "2026-09-01", columns or REGISTRY_COLUMNS, list(key),
                          rows if rows is not None else REGISTRY_ROWS, chunk_rows=chunk_rows, subject=subject,
                          dataset_key=DEMO_DATASET_KEY, **kw)


def world():
    W = {}

    def add(name, rec):
        assert name not in W, name
        rec.setdefault("schema_version", SV)
        W[name] = rec

    # ---- projects: one per product ----
    for pid, prod, title, dm in [
        ("prj_ts_pumps", "TECHSENSE", "Насосная станция НС-2", INT),
        ("prj_conflict_land", "CONFLICTOLOGY", "Конфликт вокруг участка на ул. Заречной", CONF_PD),
        ("prj_wm_region", "WEB_MONITORING", "Мониторинг СМИ: Заречный район", PUB),
        ("prj_dossier", "DOSSIER", "Досье: участники застройки ул. Заречной", CONF_PD),
        ("prj_compliance", "COMPLIANCE", "Проверки заёмщиков банка", CONF_CS_PD),
        ("prj_wiki_whales", "SEMANTIC_WIKI", "База знаний по китам", PUB)]:
        add(pid, {"kind": "Project", "project_id": pid, "tenant_id": T, "product": prod, "title": title,
                  "created_at": "2026-09-01T09:00:00Z", "default_marking": dm})

    # ---- sources (content-addressed) ----
    def src(name, kind, title, text, observed, marking, uris=None, published=None):
        rec = {"kind": "Source", "tenant_id": T, "source_kind": kind, "media_type": "text/plain; charset=utf-8",
               "language": "ru", "title": title, "content_inline": text, "marking": marking,
               "observations": [{"observed_at": observed if n == 0 else "2026-09-07T00:00:00Z", "origin_uri": u,
                                 "observed_by": "svc_webmon"} for n, u in enumerate(uris or [f"urn:demo:{name}"])]}
        if published:
            rec["published_at"] = published
        add(name, rec)

    src("s1", "DOCUMENT", "Инструкция по эксплуатации насосной станции НС-2 (фрагмент)",
        "Насос Н-101 (модель НМ 16-100, изготовитель «НасосМаш») входит в состав насосной станции НС-2. "
        "Максимальное рабочее давление насоса Н-101 — 16 бар. "
        "При давлении выше 16 бар остановить насос Н-101 и сообщить дежурному инженеру.",
        "2026-09-02T08:00:00Z", INT)
    src("s2", "MEDIA_ARTICLE", "Жители Заречной улицы против застройки",
        "ООО «Заречье-Девелопмент» получило разрешение на строительство жилого комплекса на участке 50:12:0101001:245. "
        "Жители Заречной улицы выступили против застройки. Генеральный директор компании Аркадий Ломов заявил, "
        "что работы начнутся весной.",
        "2026-09-02T10:00:00Z", PUB,
        ["https://news.example/zarechye", "https://news.example/amp/zarechye", "https://agg.example/r/123"],
        "2026-09-02T07:30:00Z")
    # S5 part 2 (D26): the raw page of the first fetch is kept in the object store; the text source was extracted from it
    W["s2"]["observations"][0]["original"] = {"$object": "raw_s2", "media_type": "text/html; charset=utf-8"}
    W["__objects__"] = {"raw_s2": ("<!doctype html><html lang=\"ru\"><head><title>Жители Заречной улицы против застройки</title></head>"
                                   "<body><nav>Главная · Новости</nav><article><p>" + W["s2"]["content_inline"] + "</p></article>"
                                   "<footer>news.example</footer></body></html>").encode("utf-8")}
    # S5 (O4): the same article fetched twice more with different bytes — extra line break and no-break space; an
    # invisible zero-width space — from the desktop site with a tracking parameter and from the mobile site
    S2 = W["s2"]["content_inline"]
    src("s2b", "MEDIA_ARTICLE", "Жители Заречной улицы против застройки",
        S2.replace(" Жители", "\n" + chr(0xA0) + "Жители", 1), "2026-09-02T10:05:00Z", PUB,
        ["https://www.news.example/zarechye?utm_source=telegram"], "2026-09-02T07:30:00Z")
    src("s2c", "MEDIA_ARTICLE", "Жители Заречной улицы против застройки",
        S2.replace("застройки.", "застрой" + chr(0x200B) + "ки.", 1), "2026-09-02T10:10:00Z", PUB,
        ["https://m.news.example/zarechye"], "2026-09-02T07:30:00Z")
    add("pub_zarechye", {"kind": "Publication", "tenant_id": T, "outlet": "news.example",
                         "canonical_url": "https://news.example/zarechye", "text_digest": {"$textdigest": "s2"},
                         "title": "Жители Заречной улицы против застройки", "published_at": "2026-09-02T07:30:00Z",
                         "marking": PUB, "recorded_at": "2026-09-02T10:15:00Z"})
    src("s3", "SOCIAL_POST", "Пост инициативной группы «Заречная, 12»",
        "Инициативная группа «Заречная, 12» начала сбор подписей против застройки участка. Депутат городского совета "
        "Нина Грачёва поддержала жителей и направила запрос в администрацию.",
        "2026-09-03T12:00:00Z", PUB)
    src("s4", "REGISTRY_EXTRACT", "Выписка ЕГРЮЛ: ООО «Заречье-Девелопмент»",
        f"ООО «Заречье-Девелопмент», ОГРН {OGRN_DEV}, ИНН {INN_DEV}. Генеральный директор: Ломов Аркадий Семёнович, "
        f"ИНН {INN_LOMOV}, дата рождения 14.03.1971, с 12.02.2021. Учредители: Ломов Аркадий Семёнович — 60%; "
        f"ООО «Северный Трубопрокат» (ОГРН {OGRN_TRUB}) — 40%.",
        "2026-09-04T09:00:00Z", PUB_PD)
    src("s5", "REGISTRY_EXTRACT", "Выписка ЕГРН: 50:12:0101001:245",
        "Земельный участок с кадастровым номером 50:12:0101001:245, адрес: Московская обл., г. Заречный, "
        "ул. Заречная, уч. 12. Правообладатель: ООО «Заречье-Девелопмент», собственность.",
        "2026-09-04T09:30:00Z", PUB)
    src("s6", "MEDIA_ARTICLE", "Суд принял иск к застройщику",
        "Арбитражный суд Московской области принял к производству иск к ООО «Заречье-Девелопмент» о взыскании "
        "задолженности по договору подряда. Делу присвоен номер А41-12345/2026.",
        "2026-09-05T08:00:00Z", PUB)
    src("s7", "DOCUMENT", "Протокол подведения итогов аукциона № 0148300000126000017",
        f"Протокол подведения итогов электронного аукциона № 0148300000126000017 от 15.08.2026. "
        f"Победитель: ООО «Заречье-Девелопмент» (ИНН {INN_DEV}). Цена контракта: 12 500 000,00 руб.",
        "2026-09-05T09:00:00Z", PUB)
    src("s8", "SOCIAL_POST", "Telegram-канал ООО «Заречье-Девелопмент»",
        "Официальный канал ООО «Заречье-Девелопмент» в Telegram: @zarechye_dev. Новости строительства и ответы "
        "на вопросы жителей.",
        "2026-09-05T10:00:00Z", PUB)
    src("s9", "MEDIA_ARTICLE", "Интервью: Аркадий Ломов о планах компании",
        "Аркадий Семёнович Ломов родился 14 марта 1972 года в Твери. С 2021 года он руководит компанией "
        "«Заречье-Девелопмент».",
        "2026-09-05T11:00:00Z", PUB)
    src("s10", "DOCUMENT", "Статья «Синий кит»",
        "Синий кит — вид усатых китов. Длина синего кита достигает 30 метров, а масса — 150 тонн.",
        "2026-09-02T09:00:00Z", PUB)
    src("s11", "REGISTRY_EXTRACT", "Сведения о регистрации транспортного средства",
        "Сведения о регистрации транспортного средства: легковой автомобиль, VIN XTA210990Y1234567, "
        "владелец Ломов Аркадий Семёнович, дата регистрации 03.06.2024.",
        "2026-09-04T10:00:00Z", PUB_PD)
    src("s12", "REGISTRY_SEARCH_RESULT", "Поиск аккаунтов в социальных сетях: Ломов Аркадий Семёнович",
        f"Поиск по ФИО «Ломов Аркадий Семёнович» и ИНН {INN_LOMOV} в социальных сетях (VK, Telegram, OK) "
        f"выполнен 27.09.2026: аккаунтов не найдено.",
        "2026-09-27T11:00:00Z", CONF_PD)
    src("s13", "REGISTRY_EXTRACT", "Выписки ЕГРЮЛ/ЕГРИП: филиал и ИП",
        f"Филиал ООО «Северный Трубопрокат» в г. Заречный, ИНН {INN_TRUB}, КПП 290145001. "
        f"Индивидуальный предприниматель Ломова Ирина Петровна, ИНН {INN_IP}, ОГРНИП {OGRNIP_IP}, "
        f"дата рождения 02.11.1975.",
        "2026-09-04T11:00:00Z", PUB_PD)

    # ---- entities ----
    def ent(name, prj, etype, identity, display, marking, status="ACTIVE", merged_into=None, changed=None):
        rec = {"kind": "Entity", "entity_id": name, "project_id": prj, "entity_type": etype, "identity": identity,
               "display_name": display, "status": status, "created_at": "2026-09-05T12:00:00Z", "marking": marking}
        if merged_into:
            rec["merged_into"] = merged_into
        if changed:
            rec["status_changed_at"] = changed
        add(name, rec)

    dev_id = {"name": "ООО «Заречье-Девелопмент»", "jurisdiction": "RU", "ogrn": OGRN_DEV, "inn": INN_DEV}
    lomov_full = {"surname": "Ломов", "given_name": "Аркадий", "patronymic": "Семёнович",
                  "birth_date": "1971-03-14", "inn": INN_LOMOV}
    # TechSense: equipment model (type) and installed instances
    ent("ent_ts_model", "prj_ts_pumps", "EQUIPMENT_MODEL", {"manufacturer": "НасосМаш", "model": "НМ 16-100"}, "Насос НМ 16-100", INT)
    ent("ent_ts_station", "prj_ts_pumps", "EQUIPMENT", {"site_id": "site_ns2", "tag": "НС-2", "description": "насосная станция"}, "Насосная станция НС-2", INT)
    ent("ent_ts_pump", "prj_ts_pumps", "EQUIPMENT", {"site_id": "site_ns2", "tag": "Н-101", "description": "насос"}, "Насос Н-101", INT)
    # Conflictology
    ent("ent_c_conflict", "prj_conflict_land", "CONFLICT", {"title": "Застройка участка на ул. Заречной", "started_on": "2026-09-02", "place": "г. Заречный"}, "Конфликт: застройка ул. Заречной", CONF_PD)
    ent("ent_c_developer", "prj_conflict_land", "ORGANIZATION", dict(dev_id), "ООО «Заречье-Девелопмент»", CONF_PD)
    ent("ent_c_initiative", "prj_conflict_land", "ORGANIZATION", {"name": "Инициативная группа «Заречная, 12»", "jurisdiction": "RU", "informal": True, "disambiguator": "zarechnaya-12"}, "Инициативная группа «Заречная, 12»", CONF_PD)
    ent("ent_c_lomov", "prj_conflict_land", "PERSON", {"surname": "Ломов", "given_name": "Аркадий", "disambiguator": "director-zarechye"}, "Ломов Аркадий", CONF_PD)
    ent("ent_c_grachyova", "prj_conflict_land", "PERSON", {"surname": "Грачёва", "given_name": "Нина", "disambiguator": "deputy-city-council"}, "Грачёва Нина", CONF_PD)
    # Web Monitoring
    ent("ent_w_developer", "prj_wm_region", "ORGANIZATION", dict(dev_id), "ООО «Заречье-Девелопмент»", PUB)
    ent("ent_w_initiative", "prj_wm_region", "ORGANIZATION", {"name": "Инициативная группа «Заречная, 12»", "jurisdiction": "RU", "informal": True, "disambiguator": "zarechnaya-12"}, "Инициативная группа «Заречная, 12»", PUB)
    # Dossier
    ent("ent_d_lomov", "prj_dossier", "PERSON", dict(lomov_full), "Ломов Аркадий Семёнович", CONF_PD)
    ent("ent_d_lomov_media", "prj_dossier", "PERSON", {"surname": "Ломов", "given_name": "Аркадий", "disambiguator": "from-s9"}, "Аркадий Ломов (из СМИ)", CONF_PD, "MERGED", "ent_d_lomov", "2026-09-06T15:00:00Z")
    ent("ent_d_developer", "prj_dossier", "ORGANIZATION", dict(dev_id), "ООО «Заречье-Девелопмент»", CONF_PD)
    ent("ent_d_trub", "prj_dossier", "ORGANIZATION", {"name": "ООО «Северный Трубопрокат»", "jurisdiction": "RU", "ogrn": OGRN_TRUB, "inn": INN_TRUB}, "ООО «Северный Трубопрокат»", CONF_PD)
    ent("ent_d_trub_branch", "prj_dossier", "ORGANIZATION", {"name": "Филиал ООО «Северный Трубопрокат» в г. Заречный", "jurisdiction": "RU", "legal_form": "BRANCH", "inn": INN_TRUB, "kpp": "290145001"}, "Филиал «Северного Трубопроката» (Заречный)", CONF_PD)
    ent("ent_d_ip", "prj_dossier", "PERSON", {"surname": "Ломова", "given_name": "Ирина", "patronymic": "Петровна", "birth_date": "1975-11-02", "inn": INN_IP, "ogrnip": OGRNIP_IP}, "ИП Ломова Ирина Петровна", CONF_PD)
    ent("ent_d_land", "prj_dossier", "REAL_ESTATE", {"cadastral_number": "50:12:0101001:245", "address": "Московская обл., г. Заречный, ул. Заречная, уч. 12"}, "Участок 50:12:0101001:245", CONF_PD)
    ent("ent_d_car", "prj_dossier", "MOVABLE_PROPERTY", {"subtype": "VEHICLE", "vin": "XTA210990Y1234567", "description": "легковой автомобиль"}, "Автомобиль VIN XTA210990Y1234567", CONF_PD)
    # Compliance
    ent("ent_k_developer", "prj_compliance", "ORGANIZATION", dict(dev_id), "ООО «Заречье-Девелопмент»", CONF_CS)
    ent("ent_k_lomov", "prj_compliance", "PERSON", dict(lomov_full), "Ломов Аркадий Семёнович", CONF_CS_PD)
    ent("ent_k_land", "prj_compliance", "REAL_ESTATE", {"cadastral_number": "50:12:0101001:245", "address": "Московская обл., г. Заречный, ул. Заречная, уч. 12"}, "Участок 50:12:0101001:245", CONF_CS)
    ent("ent_k_tender", "prj_compliance", "EVENT", {"title": "Электронный аукцион № 0148300000126000017", "date": "2026-08-15"}, "Аукцион № 0148300000126000017", CONF_CS)
    # SemanticWiki
    ent("ent_wk_blue", "prj_wiki_whales", "CONCEPT", {"label": "Синий кит", "lang": "ru", "namespace": "whales"}, "Синий кит", PUB)
    ent("ent_wk_baleen", "prj_wiki_whales", "CONCEPT", {"label": "Усатые киты", "lang": "ru", "namespace": "whales"}, "Усатые киты", PUB)
    # identity decisions (v0.2.2, RS-13/RS-15): a homonym arrives after the unqualified original — the original is
    # qualified by an append-only decision; two valves whose tags differ only by separators are declared different
    ent("ent_wk_blue_colour", "prj_wiki_whales", "CONCEPT", {"label": "Синий кит", "lang": "ru", "namespace": "whales",
        "disambiguator": "colour-name"}, "Синий кит (название оттенка)", PUB)
    W["ent_wk_blue_colour"]["created_at"] = "2026-09-06T11:00:00Z"  # after the original was qualified
    add("idd_blue_whale", {"kind": "IdentityDecision", "decision_id": "idd_blue_whale", "project_id": "prj_wiki_whales",
                           "decision": "QUALIFY", "entity_id": "ent_wk_blue", "disambiguator": "whale",
                           "decided_by": "usr_analyst1", "decided_at": "2026-09-06T10:00:00Z",
                           "note": "омоним «синий кит» (оттенок) заведён отдельно"})
    ent("ent_ts_valve_a", "prj_ts_pumps", "EQUIPMENT", {"site_id": "site_ns2", "tag": "К-1/12", "description": "задвижка"}, "Задвижка К-1/12", INT)
    ent("ent_ts_valve_b", "prj_ts_pumps", "EQUIPMENT", {"site_id": "site_ns2", "tag": "К-11/2", "description": "задвижка"}, "Задвижка К-11/2", INT)
    add("idd_valves", {"kind": "IdentityDecision", "decision_id": "idd_valves", "project_id": "prj_ts_pumps",
                       "decision": "DISTINCT", "entity_ids": ["ent_ts_valve_a", "ent_ts_valve_b"],
                       "decided_by": "usr_analyst1", "decided_at": "2026-09-06T10:00:00Z", "note": "разные задвижки по схеме НС-2"})

    # ---- claims ----
    def clm(name, prj, subj, pred, obj, evs, marking, recorded, by=None, q=None, vf=None, vt=None):
        rec = {"kind": "Claim", "project_id": prj, "subject": subj, "predicate": pred, "object": obj,
               "evidence": [{"$ev": list(e)} for e in evs],
               "produced_by": by or {"kind": "HUMAN", "actor_id": "usr_analyst1"},
               "recorded_at": recorded, "marking": marking}
        if q:
            rec["qualifiers"] = q
        if vf:
            rec["valid_from"] = vf
        if vt:
            rec["valid_to"] = vt
        add(name, rec)

    E = lambda x: {"entity": x}
    L = lambda **kw: {"literal": kw}
    PIPE = {"kind": "PIPELINE", "service_id": "svc_techsense", "run_id": "run_ts_0001"}
    t_ts = "2026-09-06T09:59:00Z"
    clm("c0", "prj_ts_pumps", "ent_ts_pump", "ts.instance_of", E("ent_ts_model"),
        [("s1", "Насос Н-101 (модель НМ 16-100, изготовитель «НасосМаш»)")], INT, t_ts, PIPE)
    clm("c1", "prj_ts_pumps", "ent_ts_pump", "ts.part_of", E("ent_ts_station"),
        [("s1", "Насос Н-101 (модель НМ 16-100, изготовитель «НасосМаш») входит в состав насосной станции НС-2")], INT, t_ts, PIPE)
    clm("c2", "prj_ts_pumps", "ent_ts_pump", "ts.has_parameter", L(type="QUANTITY", value="16", unit="bar"),
        [("s1", "Максимальное рабочее давление насоса Н-101 — 16 бар")], INT, t_ts, PIPE, q={"parameter": "max_working_pressure"})
    clm("c3", "prj_ts_pumps", "ent_ts_pump", "ts.requires_action", L(type="STRING", value="остановить насос и сообщить дежурному инженеру"),
        [("s1", "При давлении выше 16 бар остановить насос Н-101 и сообщить дежурному инженеру")], INT, t_ts, PIPE,
        q={"condition": "давление > 16 бар"})
    for cn, node in (("c0", "n10"), ("c1", "n11"), ("c2", "n12"), ("c3", "n13")):
        W[cn]["evidence"][0]["graph_node"] = {"artifact_digest": "@A:umr_ns2", "node_id": node}
    t_c = "2026-09-06T12:00:00Z"
    clm("c4", "prj_conflict_land", "ent_c_developer", "conflict.party_to", E("ent_c_conflict"),
        [("s2", "получило разрешение на строительство жилого комплекса на участке 50:12:0101001:245")], CONF_PD, t_c, q={"role": "PARTY"})
    clm("c5", "prj_conflict_land", "ent_c_initiative", "conflict.party_to", E("ent_c_conflict"),
        [("s3", "Инициативная группа «Заречная, 12» начала сбор подписей против застройки участка")], CONF_PD, t_c, q={"role": "PARTY"})
    clm("c6", "prj_conflict_land", "ent_c_grachyova", "conflict.influences", E("ent_c_conflict"),
        [("s3", "Нина Грачёва поддержала жителей и направила запрос в администрацию")], CONF_PD, t_c,
        q={"mode": "EXPLICIT", "channel": "POLITICAL"})
    clm("c7", "prj_conflict_land", "ent_c_lomov", "conflict.influences", E("ent_c_conflict"),
        [("s2", "Генеральный директор компании Аркадий Ломов заявил, что работы начнутся весной")], CONF_PD, t_c,
        q={"mode": "EXPLICIT", "channel": "ADMINISTRATIVE"})
    clm("c7b", "prj_conflict_land", "ent_c_lomov", "rel.affiliated_with", E("ent_c_developer"),
        [("s2", "Генеральный директор компании Аркадий Ломов")], CONF_PD, t_c, q={"kind": "BUSINESS", "explicit": True})
    t_w = "2026-09-06T10:30:00Z"
    clm("c8", "prj_wm_region", "ent_w_developer", "wm.mentioned", L(type="STRING", value="Жители Заречной улицы против застройки"),
        [("s2", "Жители Заречной улицы выступили против застройки")], PUB, t_w, q={"sentiment": "NEGATIVE"})
    # the same mention extracted from another rendition of the same publication (S5: counted once)
    clm("c8b", "prj_wm_region", "ent_w_developer", "wm.mentioned", L(type="STRING", value="Жители Заречной улицы против застройки"),
        [("s2b", "Жители Заречной улицы выступили против застройки")], PUB, "2026-09-06T12:30:00Z", q={"sentiment": "NEGATIVE"})
    clm("c9", "prj_wm_region", "ent_w_initiative", "wm.mentioned", L(type="STRING", value="сбор подписей против застройки"),
        [("s3", "начала сбор подписей против застройки участка")], PUB, t_w, q={"sentiment": "NEUTRAL"})
    t_d = "2026-09-06T14:00:00Z"
    clm("c10", "prj_dossier", "ent_d_lomov", "corp.director_of", E("ent_d_developer"),
        [("s4", "Генеральный директор: Ломов Аркадий Семёнович"), ("s4", "с 12.02.2021")], CONF_PD, t_d,
        q={"title": "генеральный директор"}, vf="2021-02-12")
    clm("c11", "prj_dossier", "ent_d_lomov", "corp.founder_of", E("ent_d_developer"),
        [("s4", "Ломов Аркадий Семёнович — 60%")], CONF_PD, t_d, q={"share_bp": 6000})
    clm("c12", "prj_dossier", "ent_d_trub", "corp.founder_of", E("ent_d_developer"),
        [("s4", f"ООО «Северный Трубопрокат» (ОГРН {OGRN_TRUB}) — 40%")], CONF_PD, t_d, q={"share_bp": 4000})
    clm("c13", "prj_dossier", "ent_d_lomov", "person.birth_date", L(type="DATE", value="1971-03-14"),
        [("s4", "дата рождения 14.03.1971")], CONF_PD, t_d)
    clm("c14", "prj_dossier", "ent_d_lomov_media", "person.birth_date", L(type="DATE", value="1972-03-14"),
        [("s9", "родился 14 марта 1972 года")], CONF_PD, t_d)
    clm("c15", "prj_dossier", "ent_d_developer", "prop.owns", E("ent_d_land"),
        [("s5", "Правообладатель: ООО «Заречье-Девелопмент», собственность")], CONF_PD, t_d)
    clm("c16", "prj_dossier", "ent_d_trub_branch", "corp.branch_of", E("ent_d_trub"),
        [("s13", f"Филиал ООО «Северный Трубопрокат» в г. Заречный, ИНН {INN_TRUB}, КПП 290145001")], CONF_PD, t_d)
    clm("c17", "prj_dossier", "ent_d_lomov", "prop.owns", E("ent_d_car"),
        [("s11", "VIN XTA210990Y1234567, владелец Ломов Аркадий Семёнович, дата регистрации 03.06.2024")], CONF_PD, t_d, vf="2024-06-03")
    clm("c17b", "prj_dossier", "ent_d_ip", "person.sole_proprietor", L(type="IDENTIFIER", scheme="ru.ogrnip", value=OGRNIP_IP),
        [("s13", f"Индивидуальный предприниматель Ломова Ирина Петровна, ИНН {INN_IP}, ОГРНИП {OGRNIP_IP}")], CONF_PD, t_d)
    t_k = "2026-09-07T10:00:00Z"
    clm("c18", "prj_compliance", "ent_k_developer", "media.negative_mention", L(type="STRING", value="иск о взыскании задолженности по договору подряда"),
        [("s6", "принял к производству иск к ООО «Заречье-Девелопмент» о взыскании задолженности по договору подряда")],
        CONF_CS, t_k, q={"severity": "MEDIUM"})
    clm("c19", "prj_compliance", "ent_k_developer", "court.party_to_case", L(type="IDENTIFIER", scheme="ru.arbitr", value="А41-12345/2026"),
        [("s6", "иск к ООО «Заречье-Девелопмент»"), ("s6", "Делу присвоен номер А41-12345/2026")], CONF_CS, t_k, q={"role": "DEFENDANT"})
    clm("c20", "prj_compliance", "ent_k_developer", "tender.participated", E("ent_k_tender"),
        [("s7", "Победитель: ООО «Заречье-Девелопмент»"), ("s7", "Цена контракта: 12 500 000,00 руб.")], CONF_CS, t_k,
        q={"outcome": "WON", "contract_amount_minor": 1250000000, "currency": "RUB"})
    clm("c21", "prj_compliance", "ent_k_developer", "social.account", L(type="IDENTIFIER", scheme="telegram", value="@zarechye_dev"),
        [("s8", "Официальный канал ООО «Заречье-Девелопмент» в Telegram: @zarechye_dev")], CONF_CS, t_k)
    clm("c22", "prj_compliance", "ent_k_developer", "prop.owns", E("ent_k_land"),
        [("s5", "Правообладатель: ООО «Заречье-Девелопмент», собственность")], CONF_CS, t_k)
    clm("c23", "prj_compliance", "ent_k_lomov", "corp.director_of", E("ent_k_developer"),
        [("s4", "Генеральный директор: Ломов Аркадий Семёнович")], CONF_CS_PD, t_k, vf="2021-02-12")
    t_wk = "2026-09-03T09:00:00Z"
    clm("c24", "prj_wiki_whales", "ent_wk_blue", "wiki.is_a", E("ent_wk_baleen"),
        [("s10", "Синий кит — вид усатых китов")], PUB, t_wk)
    clm("c25", "prj_wiki_whales", "ent_wk_blue", "wiki.property", L(type="QUANTITY", value="30", unit="m"),
        [("s10", "Длина синего кита достигает 30 метров")], PUB, t_wk, q={"property": "max_length"})
    clm("c26", "prj_wiki_whales", "ent_wk_blue", "wiki.property", L(type="QUANTITY", value="150", unit="t"),
        [("s10", "масса — 150 тонн")], PUB, t_wk, q={"property": "max_mass"})

    # ---- schema as data (D27.1, cycle 9): the SemanticWiki tenant models its own classes, attributes, links and
    # identifier types as RECORDS; a class of an entity is a claim (schema.is_a) with evidence like any other
    src("s20", "DOCUMENT", "Карточка вида и музейная справка",
        "Синий кит (Balaenoptera musculus): номер в каталоге ITIS — 180528. "
        "В зоологическом музее выставлен скелет синего кита длиной 27 метров.",
        "2026-09-02T09:30:00Z", PUB)
    ent("ent_wk_skeleton", "prj_wiki_whales", "THING", {"label": "Скелет синего кита", "lang": "ru", "namespace": "museum"},
        "Скелет синего кита (зоологический музей)", PUB)
    W["ent_wk_skeleton"]["schema_version"] = SV3

    def sdef(key, kind, idf, did, version, ctype, at, descr, **body):
        add(key, {"kind": kind, "schema_version": SV3, idf: did, "tenant_id": T, "version": version, **body, "marking": PUB,
                   "change": {"type": ctype, "description": descr, "recorded_at": at, "recorded_by": "usr_modeler1"}})

    max_len = {"predicate_id": "x.max_length", "name": "наибольшая длина", "value_type": "QUANTITY", "unit": "m",
               "cardinality": "ONE", "required": True}
    sdef("sd_organism", "ClassDef", "class_id", "sdf_organism", 1, "ADD_CLASS", "2026-09-02T11:59:00Z",
         "общий абстрактный класс живых организмов", root_type="CONCEPT", name="Живой организм", is_abstract=True)
    sdef("sd_taxon", "ClassDef", "class_id", "sdf_taxon", 1, "ADD_CLASS", "2026-09-02T12:00:00Z",
         "таксон: группа организмов любого ранга", root_type="CONCEPT", name="Таксон", parent_class_id="sdf_organism")
    sdef("sd_whale_v1", "ClassDef", "class_id", "sdf_whale_species", 1, "ADD_CLASS", "2026-09-02T12:01:00Z",
         "вид китов — таксон ранга вида", root_type="CONCEPT", name="Вид китов", parent_class_id="sdf_taxon",
         attributes=[max_len])
    sdef("sd_belongs", "LinkDef", "link_id", "sdf_belongs_to", 1, "ADD_LINK", "2026-09-02T12:02:00Z",
         "вид входит в таксон более высокого ранга", predicate_id="x.belongs_to", name="входит в таксон",
         domain_class_id="sdf_whale_species", range_class_id="sdf_taxon", cardinality="MANY")
    sdef("sd_exhibit", "ClassDef", "class_id", "sdf_exhibit", 1, "ADD_CLASS", "2026-09-02T12:03:00Z",
         "музейный экспонат — вещь, а не понятие", root_type="THING", name="Музейный экспонат",
         attributes=[{"predicate_id": "x.exhibit_length", "name": "длина экспоната", "value_type": "QUANTITY", "unit": "m",
                      "cardinality": "ONE", "required": False}])
    sdef("sd_itis", "IdentifierDef", "idef_id", "sdf_itis", 1, "ADD_IDENTIFIER", "2026-09-02T12:05:00Z",
         "номер таксона в каталоге ITIS", scheme="x.itis", name="Номер ITIS", applies_to_root_type="CONCEPT",
         strength="STRONG", priority=1, format=[{"chars": "DIGIT", "min": 1, "max": 9}])
    # version 2 of the class: one more attribute; claims recorded before it are read by version 1
    sdef("sd_whale_v2", "ClassDef", "class_id", "sdf_whale_species", 2, "ADD_ATTRIBUTE", "2026-09-02T12:10:00Z",
         "добавлен номер ITIS", root_type="CONCEPT", name="Вид китов", parent_class_id="sdf_taxon",
         attributes=[max_len, {"predicate_id": "x.itis_tsn", "name": "номер ITIS", "value_type": "IDENTIFIER",
                               "scheme": "x.itis", "cardinality": "ONE", "required": False}])
    t_sd = "2026-09-03T09:30:00Z"
    KREF = lambda k: {"literal": {"type": "CLASS_REF", "class_id": k}}  # noqa: E731
    clm("c40", "prj_wiki_whales", "ent_wk_baleen", "schema.is_a", KREF("sdf_taxon"), [("s10", "усатых китов")], PUB, t_sd)
    clm("c41", "prj_wiki_whales", "ent_wk_blue", "schema.is_a", KREF("sdf_whale_species"),
        [("s10", "Синий кит — вид усатых китов")], PUB, t_sd)
    clm("c42", "prj_wiki_whales", "ent_wk_blue", "x.max_length", L(type="QUANTITY", value="30", unit="m"),
        [("s10", "Длина синего кита достигает 30 метров")], PUB, t_sd)
    clm("c43", "prj_wiki_whales", "ent_wk_blue", "x.belongs_to", E("ent_wk_baleen"),
        [("s10", "Синий кит — вид усатых китов")], PUB, t_sd)
    clm("c44", "prj_wiki_whales", "ent_wk_blue", "x.itis_tsn", L(type="IDENTIFIER", scheme="x.itis", value="180528"),
        [("s20", "номер в каталоге ITIS — 180528")], PUB, t_sd)
    clm("c45", "prj_wiki_whales", "ent_wk_skeleton", "schema.is_a", KREF("sdf_exhibit"),
        [("s20", "В зоологическом музее выставлен скелет синего кита")], PUB, t_sd)
    clm("c46", "prj_wiki_whales", "ent_wk_skeleton", "x.exhibit_length", L(type="QUANTITY", value="27", unit="m"),
        [("s20", "скелет синего кита длиной 27 метров")], PUB, t_sd)
    for cn in ("c40", "c41", "c42", "c43", "c44", "c45", "c46"):
        W[cn]["schema_version"] = SV3

    # ---- a dataset version (D27.2, cycle 10): a small registry of legal entities; the claim about the address rests on
    # a ROW of it and quotes only the key and the address — the director (personal data) stays a salted leaf
    W["__datasets__"] = {"s30": demo_registry()}
    add("s30", {"kind": "Source", "schema_version": SV4, "tenant_id": T, "source_kind": "DATASET_VERSION",
                "media_type": "application/vnd.ac.dataset-manifest+json", "language": "ru",
                "title": "Реестр юридических лиц (демонстрационный), версия 2026-09-01",
                "content_inline": W["__datasets__"]["s30"].manifest_bytes.decode("utf-8"), "marking": PUB,
                "observations": [{"observed_at": "2026-09-05T08:00:00Z", "origin_uri": "urn:demo:dataset:registry:2026-09-01",
                                  "observed_by": "svc_dataset_loader"}]})
    add("c50", {"kind": "Claim", "schema_version": SV4, "project_id": "prj_compliance", "subject": "ent_k_developer",
                "predicate": "entity.registered_address", "object": L(type="STRING", value=REGISTRY_ROWS[0]["address"]),
                "evidence": [{"$row": ["s30", [OGRN_DEV], ["address"]]}],
                "produced_by": {"kind": "HUMAN", "actor_id": "usr_bank_officer"}, "recorded_at": "2026-09-26T09:00:00Z",
                "marking": CONF_CS})

    # ---- reviews: declared decision time + system record time ----
    def rev(name, claim, status, at, rec_at, note=None):
        r = {"kind": "ClaimReview", "review_id": name, "claim_id": "@C:" + claim, "status": status,
             "reviewer": "usr_reviewer1", "reviewed_at": at, "recorded_at": rec_at}
        if note:
            r["note"] = note
        add(name, r)

    rev("rev_c18_a", "c18", "ACCEPTED", "2026-09-08T10:00:00Z", "2026-09-08T10:05:00Z")
    for c in ("c19", "c20", "c21", "c22", "c23"):
        rev(f"rev_{c}_a", c, "ACCEPTED", "2026-09-20T10:00:00Z", "2026-09-20T10:05:00Z")
    rev("rev_c20_d", "c20", "DISPUTED", "2026-09-28T10:00:00Z", "2026-09-28T10:05:00Z", "контрагент оспаривает итоги аукциона")
    rev("rev_c13_a", "c13", "ACCEPTED", "2026-09-07T09:00:00Z", "2026-09-07T09:05:00Z")

    # ---- Checks: one subject, many Checks; every finding carries its search trace ----
    add("chk_express_1", {"kind": "Check", "check_id": "chk_express_1", "project_id": "prj_compliance",
        "subject_entity_id": "ent_k_developer", "profile": "EXPRESS_NEGATIVE", "as_of": "2026-09-10",
        "requested_at": "2026-09-10T08:00:00Z", "requested_by": "usr_bank_officer", "status": "COMPLETED",
        "completed_at": "2026-09-10T12:00:00Z",
        "findings": [{"dimension": "NEGATIVE", "result": "FOUND", "risk": "MEDIUM", "claim_ids": ["@C:c18"],
                      "searches": [srch("Web Monitoring: СМИ", f"ИНН {INN_DEV}", "2026-09-10T09:00:00Z")]}],
        "overall_risk": "MEDIUM", "marking": CONF_CS_PD})
    fs = "2026-09-25T10:00:00Z"
    add("chk_full_1", {"kind": "Check", "check_id": "chk_full_1", "project_id": "prj_compliance",
        "subject_entity_id": "ent_k_developer", "profile": "FULL", "as_of": "2026-09-25",
        "requested_at": "2026-09-25T08:00:00Z", "requested_by": "usr_bank_officer", "status": "COMPLETED",
        "completed_at": "2026-09-26T15:00:00Z", "previous_check_id": "chk_express_1",
        "findings": [
            {"dimension": "NEGATIVE", "result": "FOUND", "risk": "MEDIUM", "claim_ids": ["@C:c18"], "searches": [srch("Web Monitoring: СМИ", f"ИНН {INN_DEV}", fs)]},
            {"dimension": "TENDERS", "result": "FOUND", "risk": "LOW", "claim_ids": ["@C:c20"], "searches": [srch("zakupki.gov.ru", f"ИНН {INN_DEV}", fs)]},
            {"dimension": "SOCIAL_MEDIA", "result": "FOUND", "risk": "NONE", "claim_ids": ["@C:c21"], "searches": [srch("соцсети: VK, Telegram, OK", "Заречье-Девелопмент", fs)]},
            {"dimension": "CORPORATE", "result": "FOUND", "risk": "NONE", "claim_ids": ["@C:c23"], "searches": [srch("ЕГРЮЛ", f"ОГРН {OGRN_DEV}", fs)]},
            {"dimension": "PROPERTY", "result": "FOUND", "risk": "NONE", "claim_ids": ["@C:c22"], "searches": [srch("ЕГРН", f"ИНН {INN_DEV}", fs)]},
            {"dimension": "COURT", "result": "FOUND", "risk": "MEDIUM", "claim_ids": ["@C:c19"], "searches": [srch("kad.arbitr.ru", f"ИНН {INN_DEV}", fs)]}],
        "overall_risk": "MEDIUM", "marking": CONF_CS_PD})
    add("chk_tenders_1", {"kind": "Check", "check_id": "chk_tenders_1", "project_id": "prj_compliance",
        "subject_entity_id": "ent_k_developer", "profile": "TENDERS_ONLY", "as_of": "2026-09-29",
        "requested_at": "2026-09-29T09:00:00Z", "requested_by": "usr_bank_officer", "status": "IN_PROGRESS",
        "previous_check_id": "chk_full_1", "findings": [], "marking": CONF_CS_PD})
    add("chk_social_lomov", {"kind": "Check", "check_id": "chk_social_lomov", "project_id": "prj_compliance",
        "subject_entity_id": "ent_k_lomov", "profile": "SOCIAL_ONLY", "as_of": "2026-09-27",
        "requested_at": "2026-09-27T10:00:00Z", "requested_by": "usr_bank_officer", "status": "COMPLETED",
        "completed_at": "2026-09-27T12:00:00Z",
        "findings": [{"dimension": "SOCIAL_MEDIA", "result": "NOT_FOUND", "risk": "NONE", "claim_ids": [],
                      "searches": [srch("соцсети: VK, Telegram, OK", f"ФИО + ИНН {INN_LOMOV}", "2026-09-27T11:00:00Z", "s12")]}],
        "overall_risk": "NONE", "marking": CONF_CS_PD})

    # ---- TechSense as artifact producer: signed receipt; the key lives in trust anchors, not in the data ----
    add("rcp_1", {"kind": "ArtifactReceipt", "project_id": "prj_ts_pumps",
        "producer": {"service_id": "svc_techsense", "version": "0.9.0"}, "run_id": "run_ts_0001",
        "artifact_digest": "@A:umr_ns2", "artifact_schema_version": "umr-artifact/0.3", "semantic_profile_version": "ts-semantic/0.2",
        "input_source_ids": ["@S:s1"], "emitted_claim_ids": ["@C:c0", "@C:c1", "@C:c2", "@C:c3"],
        "issued_at": "2026-09-06T10:00:00Z", "key_id": "key_ts_1"})
    # the artifact itself (simplified UMR graph of instruction НС-2): stored in the object store by its digest (RR-07)
    A = lambda q: {"$anchor": ["s1", q]}
    W["__artifacts__"] = {"umr_ns2": {
        "artifact_format": "umr-artifact/0.3", "semantic_profile": "ts-semantic/0.2",
        "producer": {"service_id": "svc_techsense", "version": "0.9.0"}, "run_id": "run_ts_0001", "inputs": ["@S:s1"],
        "nodes": [
            {"id": "n1", "type": "ENTITY", "entity_type": "EQUIPMENT", "anchor": A("Насос Н-101"),
             "identity": {"site_id": "site_ns2", "tag": "Н-101", "description": "насос"}},
            {"id": "n2", "type": "ENTITY", "entity_type": "EQUIPMENT_MODEL", "anchor": A("модель НМ 16-100"),
             "identity": {"manufacturer": "НасосМаш", "model": "НМ 16-100"}},
            {"id": "n3", "type": "ENTITY", "entity_type": "EQUIPMENT", "anchor": A("насосной станции НС-2"),
             "identity": {"site_id": "site_ns2", "tag": "НС-2", "description": "насосная станция"}},
            {"id": "n4", "type": "QUANTITY", "value": "16", "unit": "bar", "anchor": A("16 бар")},
            {"id": "n5", "type": "ACTION", "text": "остановить насос и сообщить дежурному инженеру",
             "anchor": A("остановить насос Н-101 и сообщить дежурному инженеру")},
            {"id": "n6", "type": "CONDITION", "text": "давление > 16 бар", "anchor": A("При давлении выше 16 бар")},
            {"id": "n10", "type": "RELATION", "role": "instance-of", "args": ["n1", "n2"],
             "anchor": A("Насос Н-101 (модель НМ 16-100, изготовитель «НасосМаш»)")},
            {"id": "n11", "type": "RELATION", "role": "part-of", "args": ["n1", "n3"],
             "anchor": A("Насос Н-101 (модель НМ 16-100, изготовитель «НасосМаш») входит в состав насосной станции НС-2")},
            {"id": "n12", "type": "RELATION", "role": "has-parameter", "args": ["n1", "n4"], "parameter": "max_working_pressure",
             "anchor": A("Максимальное рабочее давление насоса Н-101 — 16 бар")},
            {"id": "n13", "type": "RELATION", "role": "requires-action", "args": ["n1", "n5"], "condition": "n6",
             "anchor": A("При давлении выше 16 бар остановить насос Н-101 и сообщить дежурному инженеру")}]}}
    W["__trust__"] = {"trust_format": "core-trust/0.2", "keys": [
        {"tenant_id": T, "key_id": "key_ts_1", "service_id": "svc_techsense", "algorithm": "Ed25519",
         "public_key": pub(SEEDS["key_ts_1"]), "not_before": "2026-09-01T00:00:00Z", "not_after": "2027-09-01T00:00:00Z"}]}
    return W


ORDER = ["Project", "Source", "Publication", "Entity", "IdentityDecision",
         "ClassDef", "LinkDef", "IdentifierDef",
         "Claim", "ClaimReview", "Check", "ArtifactReceipt"]


def finalize(W):
    """-> (dataset, index name->record position, trust anchors, content store {source_id: bytes})"""
    W = copy.deepcopy(W)
    trust = W.pop("__trust__")
    art_tpl = W.pop("__artifacts__", {})
    objects = W.pop("__objects__", {})
    datasets = W.pop("__datasets__", {})
    sid, cid, aid, content = {}, {}, {}, {}
    for dv in datasets.values():
        content.update(dict(dv.files))
    for n, r in W.items():
        if r["kind"] == "Source":
            b = r["content_inline"].encode("utf-8")
            r.setdefault("byte_length", len(b))
            r["source_id"] = "src:sha256:" + hashlib.sha256(b).hexdigest()
            sid[n] = r["source_id"]
            content[r["source_id"]] = b
            for o in r["observations"]:                      # originals: address and length from the object bytes
                og = o.get("original")
                if og and "$object" in og:
                    ob = objects[og.pop("$object")]
                    og["object"] = "sha256:" + hashlib.sha256(ob).hexdigest()
                    og.setdefault("byte_length", len(ob))
                    content[og["object"]] = ob

    def res(x):
        if isinstance(x, str) and x.startswith("@S:"):
            return sid[x[3:]]
        if isinstance(x, str) and x.startswith("@C:"):
            return cid[x[3:]]
        if isinstance(x, str) and x.startswith("@A:"):
            return aid[x[3:]]
        if isinstance(x, list):
            return [res(v) for v in x]
        if isinstance(x, dict):
            if "$ev" in x:
                sname, quote = x["$ev"]
                data = W[sname]["content_inline"].encode("utf-8")
                qb = quote.encode("utf-8")
                start = data.find(qb)
                assert start >= 0, (sname, quote)
                ev = {"source_id": sid[sname], "span": {"start": start, "end": start + len(qb)},
                      "quote": quote, "quote_sha256": hashlib.sha256(qb).hexdigest()}
                ev.update({k: res(v) for k, v in x.items() if k != "$ev"})
                return ev
            if "$row" in x:                 # evidence by a row of a dataset version: [source, key, quoted columns]
                sname, key_values, quote = x["$row"]
                ev = datasets[sname].evidence(key_values, quote)
                ev["source_id"] = sid[sname]
                return ev
            if "$anchor" in x:
                sname, quote = x["$anchor"]
                data, qb = W[sname]["content_inline"].encode("utf-8"), quote.encode("utf-8")
                start = data.find(qb)
                assert start >= 0, (sname, quote)
                return {"source_id": sid[sname], "start": start, "end": start + len(qb)}
            return {k: res(v) for k, v in x.items()}
        return x

    for n, r in W.items():                       # S5: publications are addressed by (tenant, outlet, normalized text)
        if r["kind"] == "Publication":
            if isinstance(r["text_digest"], dict):
                r["text_digest"] = text_digest_of(W[r["text_digest"]["$textdigest"]]["content_inline"].encode("utf-8"))
            r["publication_id"] = publication_address(r["tenant_id"], r["outlet"], r["text_digest"])

    for n, a in art_tpl.items():
        tf = a.pop("_bytes_tf", None)          # vectors: tamper with the artifact bytes BEFORE they are addressed
        b = canon_bytes(res(a))
        if tf:
            b = tf(b)
        aid[n] = "sha256:" + hashlib.sha256(b).hexdigest()
        content[aid[n]] = b

    for n, r in W.items():
        if r["kind"] == "Claim":
            patch = r.pop("_ev_patch", None)
            r.update(res(dict(r)))
            if patch:
                patch(r["evidence"])
            r["claim_id"] = "clm:sha256:" + digest({k: v for k, v in r.items() if k != "claim_id"})
            cid[n] = r["claim_id"]
    for n, r in W.items():
        if r["kind"] not in ("Source", "Claim"):
            seed = r.pop("_sign_seed", None)
            r.update(res(dict(r)))
            if r["kind"] == "ArtifactReceipt":
                r["receipt_id"] = "rcp:sha256:" + digest({k: v for k, v in r.items() if k not in ("receipt_id", "signature")})
                r["signature"] = b64u(Ed25519PrivateKey.from_private_bytes(SEEDS[seed or r["key_id"]]).sign(r["receipt_id"].encode()))
    names = sorted(W, key=lambda n: (ORDER.index(W[n]["kind"]), n))
    ds = {"dataset_format": "core-dataset/0.3", "ontology_version": SV4, "records": [W[n] for n in names]}
    return ds, {n: i for i, n in enumerate(names)}, trust, content
